package com.maveric.csp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerSessionPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerSessionPortalApplication.class, args);
	}

}
