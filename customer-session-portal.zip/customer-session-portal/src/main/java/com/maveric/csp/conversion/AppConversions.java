package com.maveric.csp.conversion;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class AppConversions {

	public static String convertDateToString(LocalDateTime currentDate) {

		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

		String convertedDate = currentDate.format(dateTimeFormatter);

		return convertedDate;

	}
}
