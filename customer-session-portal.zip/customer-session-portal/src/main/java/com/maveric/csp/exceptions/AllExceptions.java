package com.maveric.csp.exceptions;

public class AllExceptions extends RuntimeException {

	public AllExceptions(String msg) {

		super(msg);
	}

}
