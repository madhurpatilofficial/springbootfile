package com.maveric.csp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.maveric.csp.entity.User;

@Service
public interface UserSevice {
	
	public User saveUser(User user);
	public User getUserById(int userId);
	public List<User> getAllUser();
	public User updateUser(User user);
	public void deleteUserById(int userId);

}
