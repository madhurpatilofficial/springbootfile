package com.maveric.csp.CustomerSessionPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerSessionPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
